import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        ContaBancaria conta1 = new ContaBancaria("Caroline Silva", 5000.0);
        ContaBancaria conta2 = new ContaBancaria("João Pereira", 3000.0);
        ContaBancaria conta3 = new ContaBancaria("Maria Oliveira", 7000.0);

        List<ContaBancaria> contas = new ArrayList<>();

        contas.add(conta1);
        contas.add(conta2);
        contas.add(conta3);

        while (true) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Digite uma opção:");
            System.out.println("1 - Exibir detalhes das contas");
            System.out.println("2 - Realizar depósito");
            System.out.println("3 - Realizar saque");
            System.out.println("0 - Sair");
            int op = 0;
            op = scanner.nextInt();
            switch (op) {
                case 1:
                    System.out.println("\n=== Detalhes das Contas Bancárias ===");
                    for (ContaBancaria conta : contas) {
                        System.out.println(conta.exibirdados());
                        System.err.println("-----------------------------");
                    }
                    scanner.nextLine(); // Limpar o buffer do scanner

                    break;
                case 2:
                    System.out.println("\n=== Realizando Depósitos ===");
                    conta1.depositar(1000.0);
                    conta2.depositar(500.0);
                    conta3.depositar(2000.0);
                    break;
                case 3:
                    System.out.println("\n=== Realizando Saques ===");
                    conta1.sacar(1500.0);
                    conta2.sacar(3500.0);
                    conta3.sacar(800.0);
                    break;
                case 0:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida.");
            }

            System.out.println("\n=== Detalhes Atualizados das Contas Bancárias ===");
            for (ContaBancaria conta : contas) {
                System.out.println("Titular: " + conta.getTitular());
                System.out.println("Saldo Atual: R$ " + conta.getSaldo());
                System.err.println("-----------------------------");
            }

        }
    }
}

public class ContaBancaria {
    private String titular;
    private double saldo;
    private double limiteSaque = 1000.0;

    public String exibirdados() {
        return "Titular: " + titular + "\nSaldo: R$ " + saldo + "\nLimite de Saque: R$ " + limiteSaque;

    }

    public ContaBancaria(String titular, double saldo) {
        this.titular = titular;
        this.saldo = saldo;
    }

    public String getTitular() {
        return titular;
    }

    public double getSaldo() {
        return saldo;
    }

    public void depositar(double valor) {
        if (valor > 0) {
            saldo += valor;
            System.out.println("Depósito de R$ " + valor + " realizado com sucesso.");
        } else {
            System.out.println("Valor de depósito inválido.");
        }
    }

    public void sacar(double valor) {
        if (valor > 0 && valor <= limiteSaque) {
            if (saldo >= valor) {
                saldo -= valor;
                System.out.println("Saque de R$ " + valor + " realizado com sucesso.");
            } else {
                System.out.println("Saldo insuficiente para realizar o saque.");
            }
        } else {
            System.out.println("Valor de R$ " + valor + " de saque é inválido ou excede o limite de R$ " + limiteSaque);
        }
    }

    public String getLimiteSaque() {

        return String.format("%.2f", limiteSaque);
    }

}

document.addEventListener("DOMContentLoaded", function () {
    const filtroInput = document.getElementById("filtro");
    const tabela = document.querySelector(".tabela-ponto-page tbody");
    const btnRegistrar = document.getElementById("btnCadastrar");

    let linhaPendenteAtual = null;
    let horaEntradaObjeto = null;

    function obterHorarioFormatado(data) {
        return data.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    }

    function calcularDiferencaHoras(inicio, fim) {
        const diferencaMilissegundos = fim - inicio;
        const totalMinutos = Math.floor(diferencaMilissegundos / 1000 / 60);
        const horas = Math.floor(totalMinutos / 60);
        const minutos = totalMinutos % 60;
        return `${String(horas).padStart(2, '0')}:${String(minutos).padStart(2, '0')}h`;
    }

    // Lê a tarefa automática enviada pela tela de perfil
    const escolhaPuxadaPerfil = localStorage.getItem('tarefaAutomatica');
    const tipoRegistroPuxado = localStorage.getItem('tipoRegistroAutomatica');

    if (btnRegistrar) {
        btnRegistrar.addEventListener("click", function () {
            const agora = new Date();
            const horarioTexto = obterHorarioFormatado(agora);

            if (!linhaPendenteAtual) {
                horaEntradaObjeto = agora; 
                const novaLinha = document.createElement("tr");
                
                let tipoRegistro = tipoRegistroPuxado ? tipoRegistroPuxado : "Aula Normal";
                let identificadorTarefa = escolhaPuxadaPerfil ? escolhaPuxadaPerfil : "2º Ano B";
                
                novaLinha.innerHTML = `
                    <td>${tipoRegistro}</td>
                    <td>${horarioTexto} / --:--</td>
                    <td>${identificadorTarefa}</td>
                    <td>--:--</td>
                    <td>🟡 Pendente</td>
                    <td><button class="btn-tabela-ponto-pdf">PDF</button></td>
                `;

                tabela.insertBefore(novaLinha, tabela.firstChild);
                linhaPendenteAtual = novaLinha;
                btnRegistrar.textContent = "Registrar Saída";
                btnRegistrar.style.backgroundColor = "#d9534f";

                localStorage.removeItem('tarefaAutomatica');
                localStorage.removeItem('tipoRegistroAutomatica');

            } else {
                const horaEntradaTexto = obterHorarioFormatado(horaEntradaObjeto);
                const duracaoTrabalhada = calcularDiferencaHoras(horaEntradaObjeto, agora);

                linhaPendenteAtual.cells[1].textContent = `${horaEntradaTexto} / ${horarioTexto}`;
                linhaPendenteAtual.cells[3].textContent = duracaoTrabalhada;
                linhaPendenteAtual.cells[4].textContent = "🟢 Confirmado"; 

                linhaPendenteAtual = null;
                horaEntradaObjeto = null;
                btnRegistrar.textContent = "Registrar Ponto";
                btnRegistrar.style.backgroundColor = "#007bff";
            }
        });
    }

    if (filtroInput) {
        filtroInput.addEventListener("input", function () {
            const filtro = this.value.toLowerCase();
            Array.from(tabela.rows).forEach(row => {
                const textoCompleto = row.textContent.toLowerCase();
                row.style.display = textoCompleto.includes(filtro) ? "" : "none";
            });
        });
    }

    document.querySelectorAll('.item-menu-ponto-page').forEach(item => {
        item.addEventListener('click', () => {
            const label = item.querySelector('span').textContent.trim();
            if (label === 'Meu Perfil') window.location.href = 'MeuPerfil.html';
            else if (label === 'Meu Ponto') window.location.href = 'MeuPonto.html';
            else if (label === 'Configurações') window.location.href = 'Configuracoes.html';
        });
    });
});

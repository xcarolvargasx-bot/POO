document.addEventListener('DOMContentLoaded', () => {
    atualizarData();

    const selecaoTarefa = document.getElementById('selecaoTarefa');
    const containerSubTarefa = document.getElementById('containerSubTarefa');
    const containerTituloExtra = document.getElementById('containerTituloExtra');
    const selecaoSubTarefa = document.getElementById('selecaoSubTarefa');
    const txtTituloExtra = document.getElementById('txtTituloExtra');
    const tituloBloco = document.getElementById('tituloBloco');
    const txtAnotacoes = document.getElementById('txtAnotacoes');

    // Carrega anotações gerais salvas anteriormente do localStorage
    if (localStorage.getItem('anotacoesProfessor')) {
        txtAnotacoes.value = localStorage.getItem('anotacoesProfessor');
    }

    // Monitora a troca do seletor principal mantendo o bloco de texto aberto
    function alternarModoVisao() {
        if (selecaoTarefa.value === 'Aula Normal') {
            containerSubTarefa.style.display = 'block';
            containerTituloExtra.style.display = 'none';
            tituloBloco.textContent = 'Minha Grade de Hoje';
        } else if (selecaoTarefa.value === 'Atividade Extra') {
            containerSubTarefa.style.display = 'none';
            containerTituloExtra.style.display = 'block';
            tituloBloco.textContent = 'Detalhes da Atividade Extra';
        }
    }

    alternarModoVisao();
    selecaoTarefa.addEventListener('change', alternarModoVisao);

    // Botão Salvar Anotações (Disponível em ambos os modos)
    const btnSalvar = document.getElementById('btnSalvarAnotacoes');
    if (btnSalvar) {
        btnSalvar.addEventListener('click', () => {
            localStorage.setItem('anotacoesProfessor', txtAnotacoes.value);
            alert('Anotações salvas com sucesso!');
        });
    }

    // Botão de redirecionamento salvando o estado para a tela Meu Ponto
    const btnAtalho = document.getElementById('btnIrParaPonto');
    if (btnAtalho) {
        btnAtalho.addEventListener('click', () => {
            if (selecaoTarefa.value === 'Aula Normal') {
                localStorage.setItem('tarefaAutomatica', selecaoSubTarefa.value);
                localStorage.setItem('tipoRegistroAutomatica', 'Aula Normal');
            } else {
                // Captura o título curto digitado no card superior
                const tituloDigitado = txtTituloExtra.value.trim();
                localStorage.setItem('tarefaAutomatica', tituloDigitado ? tituloDigitado : 'Atividade Extra');
                localStorage.setItem('tipoRegistroAutomatica', 'Atividade Extra');
            }
            window.location.href = 'MeuPonto.html';
        });
    }

    // Navegação Sidebar
    document.querySelectorAll('.item-menu-perfil-page').forEach(item => {
        item.addEventListener('click', () => {
            const label = item.querySelector('span').textContent.trim();
            if (label === 'Meu Perfil') window.location.href = 'MeuPerfil.html';
            else if (label === 'Meu Ponto') window.location.href = 'MeuPonto.html'; 
            else if (label === 'Configurações') window.location.href = 'Configuracoes.html';
        });
    });
});

function atualizarData() {
    const elementoRelogio = document.getElementById("dataRelogio");
    if (elementoRelogio) {
        const opcoes = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const hoje = new Date();
        elementoRelogio.textContent = hoje.toLocaleDateString('pt-BR', opcoes);
    }
}

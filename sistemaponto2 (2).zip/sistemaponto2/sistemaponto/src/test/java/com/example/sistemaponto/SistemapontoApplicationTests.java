package com.example.sistemaponto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemapontoApplicationTests {

	@Test
	void contextLoads() {
	}

}

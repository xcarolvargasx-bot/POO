# Upgrade Plan: sistemaponto (20260713215959)

- **Generated**: 2026-07-13 21:59:59
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 17.0.13: C:\Program Files\Java\jdk-17\bin (current project JDK, used by baseline validation)
- JDK 25: **<TO_BE_INSTALLED>** (required by the target runtime upgrade)

**Build Tools**
- Maven Wrapper: 3.9.16 (via .mvn/wrapper/maven-wrapper.properties)

## Guidelines

- Upgrade the Java runtime to the latest LTS version in auto-execution mode.
- Keep changes minimal and preserve existing application behavior.
- Prefer the Maven wrapper for build verification.

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: N/A (git unavailable in this workspace)
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java 25

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| ---------------------- | ------- | ---------------------- | ---------------- |
| Java | 17 | 25 | User requested |
| Spring Boot | 3.5.16 | 3.5.16 | Already compatible with the requested runtime |
| Maven Wrapper | 3.9.16 | 3.9.16 | Already sufficient for the target JDK |

## Derived Upgrades

- Java 25 runtime target requires the project compiler target to be updated from 17 to 25.
- No framework migration is required because the current Spring Boot version already targets a modern Java baseline.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
| ---- | ---------- | ------- | ------ | ------ | ------ |
| pom.xml | java.version | 17 | upgrade | 25 | User requested Java 25 runtime target |

### Source Code Changes

| File | Location | Current | Required Change | Reason |
| ---- | -------- | ------- | --------------- | ------ |
| None expected | - | - | No source changes required | Current code is already compatible with the modern Spring Boot baseline |

### Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
| ---- | ---------------- | ------- | --------------- | ------ |
| None | - | - | No configuration changes required | The app does not depend on Java-version-specific config |

### CI/CD Changes

| File | Location | Current | Required Change |
| ---- | -------- | ------- | --------------- |
| None | - | - | No CI/CD files were found |

### Risks & Warnings

- The environment currently exposes only JDK 17, so the target JDK must be installed before validation.
- Build verification depends on the wrapper and the installed JDK path; this is a straightforward runtime-target change with low risk.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: The target Java runtime is not installed in the current environment, so the build must be validated with JDK 25.
  - **Changes to Make**: Install JDK 25 and verify availability.
  - **Verification**: Use appmod-list-jdks to confirm JDK 25 is available.

- Step 2: Setup Baseline
  - **Rationale**: Establish the existing build and test baseline before changing the target runtime.
  - **Changes to Make**: Run the existing Maven wrapper build and tests with the current JDK 17.
  - **Verification**: Run .\mvnw.cmd clean compile test-compile -q and .\mvnw.cmd clean test -q.

- Step 3: Upgrade Java Runtime Target
  - **Rationale**: Change the project compiler target to Java 25 while preserving the existing Spring Boot stack.
  - **Changes to Make**: Update pom.xml to set java.version to 25.
  - **Verification**: Run .\mvnw.cmd clean test-compile -q and .\mvnw.cmd clean test -q using the JDK 25 toolchain.

- Step 4: Final Validation
  - **Rationale**: Confirm the project builds and tests successfully with the upgraded runtime.
  - **Changes to Make**: Review the final diff and resolve any issues discovered during verification.
  - **Verification**: Re-run the full Maven test suite and confirm success.
